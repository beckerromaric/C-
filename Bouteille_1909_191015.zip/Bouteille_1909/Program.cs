﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bouteille_1909
{
    class Program
    {
        /// <summary>
        /// Invite l'utilisateur à saisir un nombre à virgule (de type double)
        /// Tant que la saisie de l'utilisateur est incorrecte (impossible à convertir en double), 
        /// il est invité à recommencer.
        /// Une fois la saisie validée, la fonction renvoie le nombre converti.
        /// </summary>
        /// <param name="_message">Le message à afficher à l'utilisateur (ex "veuillez saisir un nombre")</param>
        /// <returns></returns>
        static double SaisieDouble(string _message)
        {
            string saisie; // variable qui stockera la saisie de l'utilisateur
            double number; // Le nombre à renvoyer à la fin de la fonction
            
            do // répéter
            {
                Console.WriteLine(_message);
                saisie = Console.ReadLine();
            }
            while (!double.TryParse(saisie, out number)); // tant que la saisie n'est pas convertible en nombre de type double

            return number;
        }

        static void Main(string[] args)
        {
            //Str_Exemples.Go();
            double number;
            Bottle bottle; 
            ConsoleKey inputKey; 
            string ouvertFerme = "fermée";

            Console.WriteLine("Programme Bouteille");
          
            Console.ReadLine();

            number = SaisieDouble("Quelle capacité souhaitez-vous ?");

            bottle = new Bottle(number); // création d'une instance de la classe "Bottle"

            do // répéter
            {
                Console.WriteLine("Quelle opération souhaitez vous effectuer ?");

                Console.WriteLine("[O] - Ouvrir la bouteille");
                Console.WriteLine("[F] - Fermer la bouteille");
                Console.WriteLine("[R] - Remplir totalement la bouteille");
                Console.WriteLine("[V] - Vider totalement la bouteille");
                Console.WriteLine("[+] - Remplir partiellement la bouteille");
                Console.WriteLine("[-] - Vider partiellement la bouteille");
                Console.WriteLine("[Q] - Quitter le programme");

                // On demande à l'utilisateur d'appuyer sur une touche du clavier
                // Les choix disponibles sont indiqués entre parenthèses dans l'affichage ci-dessus
                inputKey = Console.ReadKey().Key; 

                 switch(inputKey) // on veut évaluer la valeur de inputKey
                 {
                    case ConsoleKey.O: // si la valeur de inputKey == ConsoleKey.O (l'utilisateur a appuyé sur la touche "O")
                        ouvertFerme = bottle.Open() ? "ouverte" : "fermée"; // opérateur ternaire
                        Console.WriteLine("La bouteille est " + ouvertFerme);
                        break;
                    case ConsoleKey.F:
                        ouvertFerme = bottle.Close() ? "ouverte" : "fermée";
                        Console.WriteLine("La bouteille est " + ouvertFerme);
                        break;
                    case ConsoleKey.R:
                        if (ouvertFerme == "ouverte")
                        {
                            bottle.Fill();
                            Console.WriteLine("\nLa bouteille est remplie, elle contient " + bottle.GetCurrentVolume() + "L\n");
                        }
                        else
                        {
                            Console.WriteLine("\nLa bouteille est fermée, aucune action de remplissage possible.\n");
                        }
                        break;
                    case ConsoleKey.V:
                        if(ouvertFerme == "fermée")
                        {
                            Console.WriteLine("\nLa bouteille est fermée, action de vidage impossible.\n");
                        }
                        else
                        {
                            bottle.Empty();
                            Console.WriteLine("\nLa bouteille est vide.\n");
                        }
                        break;
                    case ConsoleKey.Add:
                        if(ouvertFerme == "ouverte")
                        {
                            number = SaisieDouble("De quelle quantité voulez vous remplir la bouteille ? ");
                            bottle.Fill(number);

                            Console.WriteLine("\nLa bouteille contient " + bottle.GetCurrentVolume() + " L\n");
                        }
                        else
                        {
                            Console.WriteLine("La bouteille n'est pas ouverte.");
                        }
                        break;
                    case ConsoleKey.Subtract:
                        if(ouvertFerme == "ouverte")
                        {
                            number = SaisieDouble("Quelle quantité voulez vous vider ?\n");
                            bottle.Empty(number);
                            Console.WriteLine("\nLa bouteille contient " + bottle.GetCurrentVolume() + " L\n");
                        }
                        else
                        {
                            Console.WriteLine("Ouvrez la bouteille avant de la vider");
                        }
                        break;

                 }


            } while (ConsoleKey.Q != inputKey); // tant que l'utilisateur n'a pas sélectionné le choix "Q"

            Console.WriteLine("Merci !");
            Console.ReadLine();




            /* *
             * NE PAS TENIR COMPTE DU CODE SUIVANT, il sera expliqué un peu plus tard
             * */

            

        }

    }
}
