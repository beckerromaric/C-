﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bouteille_1909
{
    class Str_Exemples
    {

        public static void Go()
        {
            Console.WriteLine("STRING vs STRINGBUILDER");
            Test2();
            Test();
        }



        public static void Test()
        {
            Stopwatch t = Stopwatch.StartNew();

            string a = "";

            for (int i = 0; i < 500000; i++)
            {
                a += "a";
            }

            t.Stop();

            Console.WriteLine("STRING | Temps écoulé: " + t.Elapsed + " (" + t.ElapsedMilliseconds + "ms)");
        }

        public static void Test2()
        {
            Stopwatch t = Stopwatch.StartNew();

            StringBuilder a = new StringBuilder();

            for (int i = 0; i < 500000; i++)
            {
                a.Append("a");
            }

            t.Stop();

            Console.WriteLine("STRINGBUILDER | Temps écoulé: " + t.Elapsed + " (" + t.ElapsedMilliseconds + "ms)");
        }



    }
}
