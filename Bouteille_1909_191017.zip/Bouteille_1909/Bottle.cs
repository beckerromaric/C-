﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bouteille_1909
{
    class Bottle
    {
        private bool isOpen;

        private readonly double capacity;

        private double currentVolume;

        public EventHandler OnStateChange;


        public Bottle(double _capacity)
        {
            if (_capacity <= 0 || _capacity > 10)
            {
                throw new ArgumentOutOfRangeException("capacity", "Plage de valeurs autorisée: de 0.0001 à 10");
            }

            this.capacity = _capacity;
            this.isOpen = false;
            this.currentVolume = 0;
        }

        public bool Open()
        {
            if (isOpen)
            {
                throw new Exception("La bouteille est déjà ouverte !");
            }

            isOpen = true;
            return isOpen;
        }

        public bool Close()
        {
            if (!isOpen)
            {
                throw new Exception(
                    string.Format(
                        "La bouteille est déjà fermée ! elle contient actuellement {0}", currentVolume
                        )
                    );
            }

            isOpen = false;
            return isOpen;
        }

        public double Fill()
        {
            if(!isOpen)
            {
                throw new InvalidOperationException("Impossible de remplir une bouteille fermée !");
            }

            if(currentVolume == capacity)
            {
                throw new InvalidOperationException("Impossible de remplir une bouteille pleine !");
            }

            this.currentVolume = this.capacity;

            return currentVolume;
        }

        public double Empty()
        {
            if (!isOpen)
            {
                throw new InvalidOperationException("Impossible de vider une bouteille fermée !");
            }

            if(currentVolume == 0)
            {
                throw new InvalidOperationException("Vider une bouteille vide ? Seriously ?");
            }

            currentVolume = 0;

            return currentVolume;
        }


        public double Fill(double _quantity)
        {
            if (!isOpen)
            {
                throw new InvalidOperationException("Impossible de remplir une bouteille fermée !");
            }

            if(currentVolume == capacity)
            {
                throw new InvalidOperationException("Impossible de remplir une bouteille pleine !");
            }

            if(_quantity < 0)
            {
                throw new InvalidOperationException("Vous avez saisi une valeur négative !");
            }

            if((_quantity + currentVolume) > capacity)
            {
                throw new InvalidOperationException(
                    "Impossible de faire déborder la bouteille ! " +
                    "Vous ne pouvez rajouter plus que " + (capacity - currentVolume));
            }

            currentVolume += _quantity;

            return currentVolume;
        }

        public double Empty(double _quantity)
        {
            if(!isOpen)
            {
                throw new InvalidOperationException("Impossible de vider une bouteille fermée !");
            }

            if(currentVolume == 0)
            {
                throw new InvalidOperationException("Impossible de vider une bouteille VIDE !");
            }

            if(_quantity < 0)
            {
                throw new InvalidOperationException("Vous avez saisi une valeur négative.");
            }

            if (_quantity < currentVolume)
            {
                currentVolume -= _quantity;
            }
            else
            {
                currentVolume = 0;
            }

            return currentVolume;
        }



        public double GetCapacity()
        {
            return capacity;
        }

        public double GetCurrentVolume()
        {
            return currentVolume;
        }


    }
}
