﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bouteille_1909
{
    class Program
    {
        /// <summary>
        /// Invite l'utilisateur à saisir un nombre à virgule (de type double)
        /// Tant que la saisie de l'utilisateur est incorrecte (impossible à convertir en double), 
        /// il est invité à recommencer.
        /// Une fois la saisie validée, la fonction renvoie le nombre converti.
        /// </summary>
        /// <param name="_message">Le message à afficher à l'utilisateur (ex "veuillez saisir un nombre")</param>
        /// <returns></returns>
        static double SaisieDouble(string _message)
        {
            string saisie; // variable qui stockera la saisie de l'utilisateur
            double number; // Le nombre à renvoyer à la fin de la fonction
            
            do // répéter
            {
                Console.WriteLine(_message);
                saisie = Console.ReadLine();
                Console.WriteLine();
            }
            while (!double.TryParse(saisie, out number)); // tant que la saisie n'est pas convertible en nombre de type double

            return number;
        }

        static void Main(string[] args)
        {
            double number = 0;
            Bottle bottle = null;
            ConsoleKey inputKey = ConsoleKey.Escape;
            string ouvertFerme = "fermée";

            do
            {
                try
                {
                    Console.WriteLine("Programme Bouteille");
                    Console.WriteLine("Création de la bouteille. Quelle capacité souhaitez-vous ?");
                    number = SaisieDouble("Saisissez une valeur comprise entre 0.001 et 10: ");
                    bottle = new Bottle(number); // création d'une instance de la classe "Bottle"
                }
                catch (Exception e)
                {
                    Console.WriteLine("ERREUR: " + e.Message);
                    Console.WriteLine("Recommençons depuis le début...\n");
                }
            }
            while (bottle == null);

            do // répéter
            {
                try
                {    
                    Console.WriteLine("Quelle opération souhaitez vous effectuer ?");
                    Console.WriteLine("[O] - Ouvrir la bouteille");
                    Console.WriteLine("[F] - Fermer la bouteille");
                    Console.WriteLine("[R] - Remplir totalement la bouteille");
                    Console.WriteLine("[V] - Vider totalement la bouteille");
                    Console.WriteLine("[+] - Remplir partiellement la bouteille");
                    Console.WriteLine("[-] - Vider partiellement la bouteille");
                    Console.WriteLine("[Q] - Quitter le programme");

                    // On demande à l'utilisateur d'appuyer sur une touche du clavier
                    // Les choix disponibles sont indiqués entre crochets dans l'affichage ci-dessus
                    // Console.ReadKey() renvoie une instance de ConsoleKeyInfo
                    // La classe ConsoleKeyInfo contient une propriété "Key" qui renvoie une élément "ConsoleKey" correspondant à une touche du clavier
                    inputKey = Console.ReadKey().Key;
                    Console.WriteLine();

                    switch (inputKey) // on veut évaluer la valeur de inputKey
                    {
                        case ConsoleKey.O: // si la valeur de inputKey == ConsoleKey.O (l'utilisateur a appuyé sur la touche "O")
                            ouvertFerme = bottle.Open() ? "ouverte" : "fermée"; // opérateur ternaire
                            Console.WriteLine("La bouteille est " + ouvertFerme);
                            break;
                        case ConsoleKey.F:
                            ouvertFerme = bottle.Close() ? "ouverte" : "fermée";
                            Console.WriteLine("La bouteille est " + ouvertFerme);
                            break;
                        case ConsoleKey.R:
                            bottle.Fill();
                            Console.WriteLine("\nLa bouteille est remplie, elle contient " + bottle.GetCurrentVolume() + "L\n");
                            break;
                        case ConsoleKey.V:
                            bottle.Empty();
                            Console.WriteLine("\nLa bouteille est vide.\n");
                            break;
                        case ConsoleKey.Add: // touche "+" du pavé numérique
                            number = SaisieDouble("De quelle quantité voulez vous remplir la bouteille ? ");
                            bottle.Fill(number);
                            Console.WriteLine("\nLa bouteille contient " + bottle.GetCurrentVolume() + " L\n");
                            break;
                        case ConsoleKey.Subtract: // touche "-" du pavé numérique
                            number = SaisieDouble("Quelle quantité voulez vous vider ?\n");
                            bottle.Empty(number);
                            Console.WriteLine("\nLa bouteille contient " + bottle.GetCurrentVolume() + " L\n");
                            break;
                    }
                }
                catch(Exception e)
                {
                    Console.WriteLine("ERREUR: " + e.Message);
                    Console.WriteLine("Concentrez-vous et recommencez...\n");
                }
                
            } 
            while (ConsoleKey.Q != inputKey); // tant que l'utilisateur n'a pas sélectionné le choix "Q"

            Console.WriteLine("Programme terminé. Merci pour votre confiance !");
            Console.ReadLine();
          
        }

        static void BottleStateChanged()
        {

        }

    }
}
