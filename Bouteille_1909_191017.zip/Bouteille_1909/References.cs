﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bouteille_1909
{
    class References
    {
        static void Main(string[] args)
        {
            




            //Str_Exemples.Go();
            /*
            int a = 4;
            Console.WriteLine("a = " + a);
            Ref_Exemples.Modifier(a);
            Console.WriteLine("a = " + a);


            string b = "bonjour";
            Console.WriteLine("b = " + b);
            Ref_Exemples.Modifier(b);
            Console.WriteLine("b = " + b);

            bool c = false;
            Console.WriteLine("c = " + c);
            Ref_Exemples.Modifier(c);
            Console.WriteLine("c = " + c);

            int[] d = new int[] { 6 };
            Console.WriteLine("d = " + d[0]);
            Ref_Exemples.Modifier(d);
            Console.WriteLine("d = " + d[0]);


            Personne p = new Personne();
            Personne p2 = p;
            Personne p3 = p;
            Personne p4 = p;
            Personne p5 = p;
            p.nom = "Franck";
            p.age = 30;
            Console.WriteLine("p = " + p.nom + " " + p.age);
            Ref_Exemples.Modifier(p);
            Console.WriteLine("p = " + p.nom + " " + p.age);

            DateTime date = DateTime.Now;
            DateTime date2 = date;
            DateTime date3 = date;
            DateTime date4 = date;
            DateTime date5 = date;
            date2.AddDays(4);
            Console.WriteLine("date = " + date);
            Ref_Exemples.Modifier(date);
            Console.WriteLine("date = " + date);
            */
            Console.ReadLine();
        }
    }
}
