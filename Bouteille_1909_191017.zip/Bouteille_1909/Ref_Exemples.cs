﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bouteille_1909
{
    /// <summary>
    /// 
    /// </summary>
    class Ref_Exemples
    {
        /// <summary>
        /// Multiplie par 2 une valeur entière
        /// </summary>
        /// <param name="_valeur">La valeur à multiplier</param>
        public static void Modifier(int _valeur)
        {
            _valeur = _valeur * 2;
        }


        public static void Modifier(string _valeur)
        {
            _valeur = "Modifié: " + _valeur.ToUpper();
        }

        public static void Modifier(bool _valeur)
        {
            _valeur = !_valeur;
        }

        public static void Modifier(int[] _valeur)
        {
            _valeur[0] = _valeur[0] * 2;
            _valeur = new int[]{ 88 };
        }

        public static void Modifier(Personne _personne)
        {
            _personne.nom = "Mike";
            _personne.age = 18;
        }
        public static void Modifier(DateTime _date)
        {
            _date.AddDays(3);
        }


    }
}
